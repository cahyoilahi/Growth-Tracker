// Import fungsi yang kita perlukan dari Firebase SDK
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import { 
  getAuth, 
  createUserWithEmailAndPassword, 
  signInWithEmailAndPassword, 
  signOut, 
  onAuthStateChanged 
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";
import { 
  getFirestore, 
  doc, 
  setDoc, 
  getDoc,
  writeBatch
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";

// =================================================================
// KONFIGURASI FIREBASE - GANTI DENGAN KONFIGURASI ANDA
// =================================================================
const firebaseConfig = {
  apiKey: "AIzaSyDs-ROQwCaou-zXldtAhetQYQh0nxho1GE",
  authDomain: "rekap-growth-brand.firebaseapp.com",
  projectId: "rekap-growth-brand",
  storageBucket: "rekap-growth-brand.firebasestorage.app",
  messagingSenderId: "333644347290",
  appId: "1:333644347290:web:2d4581f1a9229232942c23",
  measurementId: "G-9W05YBTD2H"
};

// Inisialisasi Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

// --- ELEMEN DOM ---
const loginView = document.getElementById('login-view');
const socialInputView = document.getElementById('social-input-view');
const dashboardView = document.getElementById('dashboard-view');

const loginForm = document.getElementById('login-form');
const socialForm = document.getElementById('social-form');

const logoutBtn = document.getElementById('logout-btn');
const downloadPdfBtn = document.getElementById('download-pdf-btn');
const userEmailSpan = document.getElementById('user-email');

const usernameInput = document.getElementById('username');
const emailInput = document.getElementById('email-address');
const passwordInput = document.getElementById('password');
const loginErrorMessage = document.getElementById('login-error-message');

const igUserInput = document.getElementById('instagram-username');
const xUserInput = document.getElementById('x-username');
const tiktokUserInput = document.getElementById('tiktok-username');
const socialErrorMessage = document.getElementById('social-error-message');

// Elemen untuk toggle login/register
const emailFieldContainer = document.getElementById('email-field-container');
const loginBtn = document.getElementById('login-btn');
const registerBtn = document.getElementById('register-btn');
const toggleRegisterLink = document.getElementById('toggle-register-link');
const loginText = document.getElementById('login-text');

// Elemen untuk lihat password
const togglePassword = document.getElementById('toggle-password');
const eyeIcon = document.getElementById('eye-icon');
const eyeSlashIcon = document.getElementById('eye-slash-icon');

let growthChartInstance = null;
let currentUser = null;
const { jsPDF } = window.jspdf;

// --- FUNGSI UTAMA ---

// Fungsi untuk menampilkan view/halaman yang benar
function showView(viewName) {
    loginView.style.display = 'none';
    socialInputView.style.display = 'none';
    dashboardView.style.display = 'none';

    if (viewName === 'login') loginView.style.display = 'flex';
    if (viewName === 'social-input') socialInputView.style.display = 'flex';
    if (viewName === 'dashboard') dashboardView.style.display = 'block';
}

// Listener utama untuk status otentikasi
onAuthStateChanged(auth, async (user) => {
    if (user) {
        currentUser = user;
        userEmailSpan.textContent = user.email;

        const userDocRef = doc(db, "users", user.uid);
        const docSnap = await getDoc(userDocRef);

        if (docSnap.exists() && docSnap.data().socialProfiles) {
            const profiles = docSnap.data().socialProfiles;
            document.getElementById('ig-card-username').textContent = `@${profiles.instagram}`;
            document.getElementById('x-card-username').textContent = `@${profiles.x}`;
            document.getElementById('tiktok-card-username').textContent = `@${profiles.tiktok}`;
            
            showView('dashboard');
            initChart();
        } else {
            showView('social-input');
        }
    } else {
        currentUser = null;
        showView('login');
        if (growthChartInstance) {
            growthChartInstance.destroy();
            growthChartInstance = null;
        }
    }
});


// --- EVENT LISTENERS ---

// Logika untuk toggle antara mode Daftar dan Masuk
let isRegisterMode = false;
toggleRegisterLink.addEventListener('click', (e) => {
    e.preventDefault();
    isRegisterMode = !isRegisterMode;
    if (isRegisterMode) {
        emailFieldContainer.classList.remove('hidden');
        loginBtn.classList.add('hidden');
        registerBtn.classList.remove('hidden');
        toggleRegisterLink.textContent = "Sudah punya akun? Masuk";
        loginText.textContent = "Daftar akun baru.";
        emailInput.required = true;
    } else {
        emailFieldContainer.classList.add('hidden');
        loginBtn.classList.remove('hidden');
        registerBtn.classList.add('hidden');
        toggleRegisterLink.textContent = "Daftar di sini";
        loginText.textContent = "Belum punya akun?";
        emailInput.required = false;
    }
});

// Logika untuk tombol MASUK
loginBtn.addEventListener('click', async (e) => {
    e.preventDefault();
    const username = usernameInput.value.trim().toLowerCase();
    const password = passwordInput.value;
    if (!username || !password) {
        loginErrorMessage.textContent = "Username dan password harus diisi.";
        loginErrorMessage.classList.remove('hidden');
        return;
    }
    
    loginErrorMessage.classList.add('hidden');

    try {
        const usernameDocRef = doc(db, "usernames", username);
        const usernameDocSnap = await getDoc(usernameDocRef);

        if (!usernameDocSnap.exists()) {
            throw new Error("Username tidak ditemukan.");
        }

        const userEmail = usernameDocSnap.data().email;
        await signInWithEmailAndPassword(auth, userEmail, password);
        console.log("Login dengan username berhasil!");

    } catch (error) {
        console.error("Gagal login:", error);
        loginErrorMessage.textContent = "Username atau password salah.";
        loginErrorMessage.classList.remove('hidden');
    }
});

// Logika untuk tombol DAFTAR
registerBtn.addEventListener('click', async (e) => {
    e.preventDefault();
    const username = usernameInput.value.trim().toLowerCase();
    const email = emailInput.value;
    const password = passwordInput.value;

    if (!username || !email || !password) {
        loginErrorMessage.textContent = "Username, email, dan password harus diisi.";
        loginErrorMessage.classList.remove('hidden');
        return;
    }

    loginErrorMessage.classList.add('hidden');

    const usernameDocRef = doc(db, "usernames", username);
    const usernameDocSnap = await getDoc(usernameDocRef);

    if (usernameDocSnap.exists()) {
        loginErrorMessage.textContent = "Username ini sudah digunakan. Silakan pilih yang lain.";
        loginErrorMessage.classList.remove('hidden');
        return;
    }

    try {
        const userCredential = await createUserWithEmailAndPassword(auth, email, password);
        const user = userCredential.user;
        
        const batch = writeBatch(db);
        const userDocRef = doc(db, "users", user.uid);
        batch.set(userDocRef, { username: username, email: email });

        const usernameRef = doc(db, "usernames", username);
        batch.set(usernameRef, { email: email, userId: user.uid });
        
        await batch.commit();
        console.log("Data user dan username berhasil disimpan di Firestore.");

    } catch (error) {
        console.error("Gagal mendaftar:", error);
        loginErrorMessage.textContent = error.message;
        loginErrorMessage.classList.remove('hidden');
    }
});

// Event listener untuk form input sosial media
socialForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const igValue = igUserInput.value.trim();
    const xValue = xUserInput.value.trim();
    const tiktokValue = tiktokUserInput.value.trim();

    if (igValue === '' || xValue === '' || tiktokValue === '') {
        socialErrorMessage.classList.remove('hidden');
        return;
    }
    socialErrorMessage.classList.add('hidden');

    if (currentUser) {
        const userDocRef = doc(db, "users", currentUser.uid);
        try {
            await setDoc(userDocRef, { 
                socialProfiles: {
                    instagram: igValue,
                    x: xValue,
                    tiktok: tiktokValue
                } 
            }, { merge: true });
        } catch (error) {
            console.error("Gagal menyimpan data ke Firestore:", error);
            alert("Gagal menyimpan data. Silakan coba lagi.");
        }
    }
});

// Event listener untuk tombol logout
logoutBtn.addEventListener('click', () => {
    signOut(auth).catch((error) => console.error("Gagal logout:", error));
});

// Event listener untuk filter waktu grafik
document.querySelectorAll('.time-btn').forEach(button => {
    button.addEventListener('click', () => initChart(button.dataset.days));
});

// Event listener untuk download PDF
downloadPdfBtn.addEventListener('click', () => {
    const chartContainer = document.getElementById('chart-container');
    html2canvas(chartContainer, { backgroundColor: '#1e293b' }).then(canvas => {
        const imgData = canvas.toDataURL('image/png');
        const pdf = new jsPDF({ orientation: 'landscape', unit: 'px', format: [canvas.width, canvas.height] });
        pdf.addImage(imgData, 'PNG', 0, 0, canvas.width, canvas.height);
        pdf.save('laporan-pertumbuhan.pdf');
    });
});

// Event listener untuk tombol lihat/sembunyikan password
togglePassword.addEventListener('click', () => {
    const isPassword = passwordInput.type === 'password';
    passwordInput.type = isPassword ? 'text' : 'password';
    eyeIcon.classList.toggle('hidden', isPassword);
    eyeSlashIcon.classList.toggle('hidden', !isPassword);
});


// --- FUNGSI GRAFIK ---
async function initChart(period = '30') {
    if (growthChartInstance) { growthChartInstance.destroy(); }
    
    // Di aplikasi nyata, data ini akan diambil dari sub-koleksi 'growthData' di Firestore
    // yang diisi oleh Cloud Function setiap hari.
    const mockData = {
        '7': { labels: ['Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab', 'Min'], followers: [124, 126, 129, 135, 140, 148, 155], likes: [5.2, 5.8, 6.1, 5.5, 7.2, 8.0, 7.5] },
        '30': { labels: ['Minggu 1', 'Minggu 2', 'Minggu 3', 'Minggu 4'], followers: [105, 112, 119, 125.6], likes: [10.5, 12.1, 11.8, 10.8] },
        '90': { labels: ['Bulan 1', 'Bulan 2', 'Bulan 3'], followers: [88, 105, 125.6], likes: [35.2, 40.1, 45.2] }
    };
    const data = mockData[period] || mockData['30'];

    const ctx = document.getElementById('growthChart').getContext('2d');
    growthChartInstance = new Chart(ctx, {
        type: 'line',
        data: {
            labels: data.labels,
            datasets: [
                { label: 'Pengikut (K)', data: data.followers, borderColor: '#6366f1', backgroundColor: 'rgba(99, 102, 241, 0.1)', borderWidth: 3, tension: 0.4, fill: true },
                { label: 'Suka (K)', data: data.likes, borderColor: '#ec4899', backgroundColor: 'rgba(236, 72, 153, 0.1)', borderWidth: 3, tension: 0.4, fill: true }
            ]
        },
        options: { responsive: true, maintainAspectRatio: false, scales: { y: { beginAtZero: false, grid: { color: 'rgba(255, 255, 255, 0.1)' }, ticks: { color: '#94a3b8', callback: (v) => v + 'K' } }, x: { grid: { display: false }, ticks: { color: '#94a3b8' } } }, plugins: { legend: { position: 'top', align: 'end', labels: { color: '#cbd5e1', usePointStyle: true, boxWidth: 8 } }, tooltip: { backgroundColor: '#1e293b', titleColor: '#ffffff', bodyColor: '#cbd5e1', borderColor: '#334155', borderWidth: 1, padding: 10, callbacks: { label: (c) => `${c.dataset.label}: ${c.parsed.y}K` } } }, interaction: { mode: 'index', intersect: false } }
    });

    document.querySelectorAll('.time-btn').forEach(btn => {
        btn.classList.toggle('btn-active', btn.dataset.days === period);
    });
}

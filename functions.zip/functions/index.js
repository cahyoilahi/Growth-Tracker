// File: functions/index.js

const functions = require("firebase-functions");
const admin = require("firebase-admin");
const axios = require("axios");
const cheerio = require("cheerio"); // Library untuk mengurai HTML

// Inisialisasi Firebase Admin
admin.initializeApp();
const db = admin.firestore();

// --- FUNGSI-FUNGSI SCRAPER UNTUK SETIAP PLATFORM ---

/**
 * FUNGSI SCRAPER UNTUK INSTAGRAM
 * @param {string} username - Username Instagram
 * @returns {Promise<object>}
 */
async function scrapeInstagramStats(username) {
    if (!username) return { followers: 0, likes: 0 };
    const url = `https://www.instagram.com/${username}/`;
    console.log(`[SCRAPER] Mencoba mengambil data dari: ${url}`);
    try {
        const headers = { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36' };
        const response = await axios.get(url, { headers });
        const html = response.data;
        const $ = cheerio.load(html);
        let followersCount = 0;
        $('script[type="application/ld+json"]').each((i, el) => {
            const scriptContent = $(el).html();
            if (scriptContent) {
                try {
                    const jsonData = JSON.parse(scriptContent);
                    if (jsonData.mainEntityofPage && jsonData.mainEntityofPage.interactionStatistic) {
                        const stats = jsonData.mainEntityofPage.interactionStatistic;
                        const followerStat = stats.find(stat => stat.interactionType === 'http://schema.org/FollowAction');
                        if (followerStat) {
                            followersCount = parseInt(followerStat.userInteractionCount, 10);
                        }
                    }
                } catch (e) { /* Abaikan error parsing */ }
            }
        });
        console.log(`[SCRAPER] Instagram followers untuk ${username}: ${followersCount}`);
        return { followers: followersCount, likes: 0 };
    } catch (error) {
        console.error(`[SCRAPER] Gagal mengambil data Instagram untuk ${username}:`, error.message);
        return { followers: 0, likes: 0 };
    }
}

/**
 * FUNGSI SCRAPER UNTUK X (TWITTER)
 * @param {string} username - Username X
 * @returns {Promise<object>}
 */
async function scrapeXStats(username) {
    if (!username) return { followers: 0, likes: 0 };
    const url = `https://twitter.com/${username}`;
    console.log(`[SCRAPER] Mencoba mengambil data dari: ${url}`);
    try {
        const headers = { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36' };
        const response = await axios.get(url, { headers });
        const html = response.data;
        const $ = cheerio.load(html);
        // Selector ini mencari link yang menuju ke halaman followers dan mengambil teksnya
        const followersText = $(`a[href="/${username}/followers"] span span`).first().text();
        const followersCount = parseInt(followersText.replace(/,/g, ''), 10) || 0;
        console.log(`[SCRAPER] X followers untuk ${username}: ${followersCount}`);
        return { followers: followersCount, likes: 0 };
    } catch (error) {
        console.error(`[SCRAPER] Gagal mengambil data X untuk ${username}:`, error.message);
        return { followers: 0, likes: 0 };
    }
}

/**
 * FUNGSI SCRAPER UNTUK TIKTOK
 * @param {string} username - Username TikTok
 * @returns {Promise<object>}
 */
async function scrapeTikTokStats(username) {
    if (!username) return { followers: 0, likes: 0 };
    const url = `https://www.tiktok.com/@${username}`;
    console.log(`[SCRAPER] Mencoba mengambil data dari: ${url}`);
    try {
        const headers = { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36' };
        const response = await axios.get(url, { headers });
        const html = response.data;
        const $ = cheerio.load(html);
        // Selector ini mencari elemen strong dengan atribut data-e2e="followers-count"
        const followersText = $('strong[data-e2e="followers-count"]').text();
        const followersCount = parseInt(followersText.replace(/\./g, ''), 10) || 0;
        console.log(`[SCRAPER] TikTok followers untuk ${username}: ${followersCount}`);
        return { followers: followersCount, likes: 0 };
    } catch (error) {
        console.error(`[SCRAPER] Gagal mengambil data TikTok untuk ${username}:`, error.message);
        return { followers: 0, likes: 0 };
    }
}


// --- FUNGSI UTAMA YANG DIJADWALKAN ---
// Fungsi ini akan berjalan secara otomatis setiap hari pada jam 5 pagi.
exports.fetchAndStoreDailyStats = functions.pubsub.schedule('0 5 * * *')
    .timeZone('Asia/Jakarta') // Atur zona waktu Anda
    .onRun(async (context) => {
        
        const usersSnapshot = await db.collection('users').get();
        if (usersSnapshot.empty) {
            console.log("Tidak ada pengguna untuk diproses.");
            return null;
        }

        for (const userDoc of usersSnapshot.docs) {
            const userId = userDoc.id;
            const socialProfiles = userDoc.data().socialProfiles;

            if (!socialProfiles) {
                console.log(`Melewatkan pengguna ${userId} karena tidak ada profil sosial media.`);
                continue;
            }

            try {
                // Panggil semua fungsi scraper secara bersamaan
                const [igData, xData, tiktokData] = await Promise.all([
                    scrapeInstagramStats(socialProfiles.instagram),
                    scrapeXStats(socialProfiles.x),
                    scrapeTikTokStats(socialProfiles.tiktok)
                ]);

                const today = new Date().toISOString().split('T')[0]; // Format: YYYY-MM-DD

                // Simpan semua data ke sub-koleksi 'growthData'
                await db.collection('users').doc(userId).collection('growthData').doc(today).set({
                    instagram: igData,
                    x: xData,
                    tiktok: tiktokData,
                    timestamp: admin.firestore.FieldValue.serverTimestamp()
                }, { merge: true });

                console.log(`Data berhasil disimpan untuk pengguna: ${userId}`);

            } catch (error) {
                console.error(`Gagal memproses data untuk pengguna ${userId}:`, error);
            }
        }
        
        return null;
    });
